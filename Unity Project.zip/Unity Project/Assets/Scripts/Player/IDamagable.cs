﻿public interface IDamagable
{
    void TakeDamage(int damage);
}
